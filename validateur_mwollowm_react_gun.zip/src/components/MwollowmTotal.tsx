import { useEffect, useState } from 'react';
import { gun } from '../gun';

export function MwollowmTotal() {
  const [total, setTotal] = useState(0);

  useEffect(() => {
    const circulation = gun.get("mwollowm_circulation");
    let cumul = 0;

    circulation.map().on(data => {
      if (data?.valeur) {
        cumul += parseFloat(data.valeur);
        setTotal(parseFloat(cumul.toFixed(18)));
      }
    });
  }, []);

  return (
    <div>
      <h2>Total de mwollowm validés :</h2>
      <p style={{ fontSize: '24px', color: '#0f0' }}>{total}</p>
    </div>
  );
}