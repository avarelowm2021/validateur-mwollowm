import Gun from 'gun';
import 'gun/sea';
import 'gun/axe';

export const gun = Gun({
  peers: ['https://gun-dfax.onrender.com/gun'],
});