import { MwollowmTotal } from './components/MwollowmTotal';

function App() {
  return (
    <div style={{ padding: '20px', fontFamily: 'monospace', background: '#111', color: '#0f0' }}>
      <h1>🌍 Validateur Mwollowm</h1>
      <MwollowmTotal />
    </div>
  );
}

export default App;